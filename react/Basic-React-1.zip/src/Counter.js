const Counter = (props) => {
  return (
    <center>
      <h1>{props.count}</h1>
      <button onClick={props.incCount}>INC</button>
    </center>
  );
};

export default Counter;
