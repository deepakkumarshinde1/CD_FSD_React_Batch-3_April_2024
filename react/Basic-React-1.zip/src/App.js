import { useState } from "react";
import Counter from "./Counter";

// logic --> Component
function App() {
  let [count, setCount] = useState(0); // [value, updateFunction]
  let incCount = () => {
    setCount(count + 1);
  };
  return (
    <>
      <Counter count={count} incCount={incCount} />
    </>
  );
}

// export
export default App;
