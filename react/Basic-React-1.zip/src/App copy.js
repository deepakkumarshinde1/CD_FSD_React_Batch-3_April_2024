import { useState } from "react";

// logic --> Component
function App() {
  let [count, setCount] = useState(0); // [value, updateFunction]
  let incCount = () => {
    setCount(count + 1);
  };
  return (
    <>
      <center>
        <h1>{count}</h1>
        <button onClick={incCount}>INC</button>
      </center>
    </>
  );
}

// export
export default App;
